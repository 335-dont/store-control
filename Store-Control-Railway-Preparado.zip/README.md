# Store Control — Etapa 9A: base da API

Este ZIP contém o **frontend original da Etapa 8, sem modificações**, em `frontend/`, e uma **base inicial** FastAPI/PostgreSQL em `backend/`. Não há integração entre eles nesta entrega.

## Requisitos
- Node.js + npm para o frontend
- Docker Desktop com Docker Compose para a API e PostgreSQL

## Iniciar backend (PowerShell ou terminal, na raiz)
1. `docker compose up -d --build`
2. `docker compose exec api python init_db.py` (somente na primeira inicialização)
3. Abrir `http://localhost:8000/docs` e `http://localhost:8000/health`

## Iniciar painel (outro terminal)
1. `cd frontend`
2. `npm install`
3. `npm run dev`
4. Abrir `http://localhost:5173`

## Escopo desta entrega
- Tabelas iniciais para catálogos, produtos, pedidos, itens e auditoria.
- Endpoints demonstrativos para listar/criar catálogos e produtos, sem autenticação.
- Banco persistido em volume Docker.
- O painel **continua usando localStorage**. Os dados locais não são migrados automaticamente.
- Não use endpoints para vendas reais ou em ambiente público: **faltam OAuth, controle de acesso, migrações Alembic, reserva transacional, idempotência, bot Discord e sincronização**.
- `init_db.py` usa `create_all` apenas para bootstrap local; as próximas mudanças de esquema deverão usar Alembic.

## Atenção
Não execute `docker compose down -v` se quiser preservar os dados do PostgreSQL: a opção `-v` apaga o volume. Não coloque tokens ou senhas reais em arquivos versionados.

## Etapa 9B — Migração experimental (sem sobrescrever dados)

Esta etapa adiciona `GET /api/snapshot` e `POST /api/migration/import` e três controles na página Produtos: **Baixar backup JSON**, **Consultar banco** e **Importar dados locais para banco vazio**.

1. Faça backup JSON do navegador antes de qualquer operação.
2. Inicie Docker e API como na etapa anterior; `docker compose up -d --build`.
3. Execute `docker compose exec api python init_db.py` caso seja um banco novo.
4. Execute o frontend com `cd frontend`, `npm install`, `npm run dev`.
5. Abra Produtos, consulte o banco e, somente se estiver vazio, importe seus dados locais.
6. A API rejeita importações em banco não vazio (HTTP 409). A importação é transacional; IDs locais são mapeados para IDs inteiros do PostgreSQL.

**Atenção:** nesta etapa o frontend permanece localStorage; importar apenas copia uma vez, não sincroniza edições posteriores. Não existe autenticação; não publique API/DB na internet. A API e o PostgreSQL permanecem limitados a 127.0.0.1 no docker-compose. Para acesso remoto/iPhone, a futura implantação exigirá HTTPS e autenticação. Não abra portas no roteador.
